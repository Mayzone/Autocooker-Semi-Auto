function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

if not is_playing() then 
	return
end

mission_table = {
	["crojob2"] = {
	{ text = "AutoCooker - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker.lua") end },
	{ text = "AutoCooker - Semi Auto - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker semi auto.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker secure.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add more.lua") end
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add less.lua") end },	},
	},
	["alex_1"] = {
	{ text = "AutoCooker - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker.lua") end },
	{ text = "AutoCooker - Semi Auto - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker semi auto.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker secure.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add more.lua") end
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add less.lua") end },	},
	},
	["rat"] = {
	{ text = "AutoCooker - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker.lua") end },
	{ text = "AutoCooker - Semi Auto - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker semi auto.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker secure.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add more.lua") end
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add less.lua") end },	},
	},
	["mia_1"] = {
	{ text = "AutoCooker - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker.lua") end },
	{ text = "AutoCooker - Semi Auto - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker semi auto.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker secure.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add more.lua") end
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add less.lua") end },	},
	},
	["mex_cooking"] = {
	{ text = "AutoCooker - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker.lua") end },
	{ text = "AutoCooker - Semi Auto - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker semi auto.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker secure.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add more.lua") end
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add less.lua") end },	},
	},
	["cane"] = {
	{ text = "AutoCooker - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker.lua") end },
	{ text = "AutoCooker - Semi Auto - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker semi auto.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker secure.lua") end },
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add more.lua") end
	{ text = "AutoCooker - Secure Bags On Spawn - ON/OFF", callback_func = function() dofile("mods/custom hook/autocooker add less.lua") end },	},
	},
}

function mission_menu()
	local dialog_data = {    
		title = "Autocooker Menu",
		text = "Select Option",
		button_list = {}
	}
	
	local list = {
		managers.job:current_level_id(),
	}
	for _, absolute_list in pairs(list) do
		for _, mission_func in pairs(mission_table[absolute_list]) do
			table.insert(dialog_data.button_list, mission_func)
		end
	end

	table.insert(dialog_data.button_list, {})
	table.insert(dialog_data.button_list, { text = managers.localization:text("dialog_cancel"), focus_callback_func = function () end, cancel_button = true }) 
	managers.system_menu:show_buttons(dialog_data)
end
mission_menu()