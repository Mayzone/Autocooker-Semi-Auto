if not rawget(_G, "BetterDelayedCalls") then
	rawset(_G, "BetterDelayedCalls", {})
	BetterDelayedCalls._calls = {}
	
	function BetterDelayedCalls:Update(t, dt)
		for k, v in pairs(self._calls) do 
			if self._calls[k] ~=  nil then
				v.currentTime = v.currentTime + dt
				if v.currentTime >= v.timeToWait then
					if v.functionCall then
						v.functionCall()
					end

					if v.loop then
						v.currentTime = 0
					else
						self:Remove(k)
					end
				end
			end
		end
	end

	function BetterDelayedCalls:Add(id, time, func, sloop)
		if not self._calls[id] then
			local queuedFunc = {
				functionCall = func,
				timeToWait = time,
				currentTime = 0,
				loop = (sloop or false)
			}
			self._calls[id] = queuedFunc
		end
	end

	function BetterDelayedCalls:Remove( id )
		self._calls[id] = nil
	end

	if RequiredScript == "lib/managers/menumanager" then
		local __orig = MenuManager.update
		function MenuManager:update(t, dt)
			__orig(self, t, dt)
			BetterDelayedCalls:Update(t, dt)
		end
	end
end