function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

if not is_playing() then
	return
end

id_level = managers.job:current_level_id()
if not (id_level == 'cane' or id_level == 'mex_cooking' or id_level == 'alex_1' or id_level == 'rat' or id_level == 'crojob2' or id_level == 'mia_1') then
	return
end

if global_toggle_meth then
	global_semi_auto = global_semi_auto or false
	if not global_semi_auto then
		global_semi_auto_toggle = true
		managers.mission._fading_debug_output:script().log(tostring'Semi Auto - ACTIVATED',  Color.green)
	else
		global_semi_auto_toggle = false
		managers.mission._fading_debug_output:script().log(tostring'Semi Auto - DEACTIVATED',  Color.red)
	end
	global_semi_auto = not global_semi_auto
else
	managers.chat:feed_system_message(ChatManager.GAME, "Enable Autocooker First")
end